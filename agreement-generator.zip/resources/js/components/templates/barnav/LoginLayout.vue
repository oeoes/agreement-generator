<template>
  <span>
      <slot></slot>
  </span>
</template>

<script>
export default {

}
</script>

<style>

</style>